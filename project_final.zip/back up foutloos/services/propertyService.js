import prisma from "../prismaClient.js";

export const getAllProperties = async (req, res) => {
  const { location, pricePerNight } = req.query;

  let filter = {};

  if (location) {
    filter.location = { contains: location };
  }

  if (pricePerNight) {
    filter.pricePerNight = parseFloat(pricePerNight);
  }

  try {
    const properties = await prisma.property.findMany({
      where: filter,
    });
    res.json(properties);
  } catch (error) {
    console.error("Error fetching properties:", error);
    res.status(500).json({ error: "Error fetching properties" });
  }
};

export const createProperty = async (req, res) => {
  const {
    title,
    description,
    location,
    pricePerNight,
    bedroomCount,
    bathRoomCount,
    maxGuestCount,
    hostId,
  } = req.body;

  if (
    !title ||
    !description ||
    !location ||
    !pricePerNight ||
    !bedroomCount ||
    !bathRoomCount ||
    !maxGuestCount ||
    !hostId
  ) {
    return res.status(400).json({ error: "All fields are required" });
  }

  try {
    const newProperty = await prisma.property.create({
      data: {
        title,
        description,
        location,
        pricePerNight,
        bedroomCount,
        bathRoomCount,
        maxGuestCount,
        host: {
          connect: { id: hostId },
        },
      },
    });
    res.status(201).json(newProperty);
  } catch (error) {
    console.error("Error creating property:", error);
    res.status(500).json({ error: "Error creating property" });
  }
};

export const getPropertyById = async (req, res) => {
  const { id } = req.params;

  try {
    const property = await prisma.property.findUnique({
      where: { id },
    });
    if (property) {
      res.json(property);
    } else {
      res.status(404).json({ error: "Property not found" });
    }
  } catch (error) {
    console.error("Error fetching property:", error);
    res.status(500).json({ error: "Error fetching property" });
  }
};

export const updateProperty = async (req, res) => {
  const { id } = req.params;
  const {
    title,
    description,
    location,
    pricePerNight,
    bedroomCount,
    bathRoomCount,
    maxGuestCount,
    hostId,
  } = req.body;

  if (
    !title ||
    !description ||
    !location ||
    !pricePerNight ||
    !bedroomCount ||
    !bathRoomCount ||
    !maxGuestCount ||
    !hostId
  ) {
    return res.status(200).json({ error: "All fields are required" });
  }

  try {
    const updatedProperty = await prisma.property.update({
      where: { id },
      data: {
        title,
        description,
        location,
        pricePerNight,
        bedroomCount,
        bathRoomCount,
        maxGuestCount,
        host: {
          connect: { id: hostId },
        },
      },
    });
    res.json(updatedProperty);
  } catch (error) {
    console.error("Error updating property:", error);
    res.status(500).json({ error: "Error updating property" });
  }
};

export const deleteProperty = async (req, res) => {
  const { id } = req.params;

  try {
    await prisma.property.delete({
      where: { id },
    });
    res.status(204).send();
  } catch (error) {
    console.error("Error deleting property:", error);
    res.status(404).json({ error: "Error deleting property" });
  }
};

export const searchProperties = async (req, res) => {
  const { query } = req.query;

  if (!query) {
    return res.status(400).json({ error: "Query is required" });
  }

  try {
    const properties = await prisma.property.findMany({
      where: {
        OR: [
          { title: { contains: query } },
          { description: { contains: query } },
          { location: { contains: query } },
        ],
      },
    });
    res.json(properties);
  } catch (error) {
    console.error("Error searching properties:", error);
    res.status(500).json({ error: "Error searching properties" });
  }
};
