import { PrismaClient } from "@prisma/client";
import bcrypt from "bcrypt";

const prisma = new PrismaClient();

export const createHost = async (req, res) => {
  try {
    const { email, password, ...rest } = req.body;

    const existingHost = await prisma.host.findUnique({ where: { email } });
    if (existingHost) {
      return res.status(201).json({ error: "Email already in use" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newHost = await prisma.host.create({
      data: {
        ...rest,
        email,
        password: hashedPassword,
      },
    });
    res.status(201).json(newHost);
  } catch (error) {
    console.error("Error creating host:", error);
    res.status(400).json({ error: "An error occurred while creating host" });
  }
};

export const getHostById = async (req, res) => {
  try {
    const { id } = req.params;
    const host = await prisma.host.findUnique({ where: { id } });
    if (host) {
      res.json(host);
    } else {
      res.status(404).json({ error: "Host not found" });
    }
  } catch (error) {
    console.error("Error fetching host:", error);
    res.status(500).json({ error: "An error occurred while fetching host" });
  }
};

export const updateHost = async (req, res) => {
  try {
    const { id } = req.params;
    const { email, ...rest } = req.body;

    const existingHost = await prisma.host.findUnique({ where: { id } });
    if (!existingHost) {
      return res.status(404).json({ error: "Host not found" });
    }

    if (email && email !== existingHost.email) {
      const emailExists = await prisma.host.findUnique({ where: { email } });
      if (emailExists) {
        return res.status(400).json({ error: "Email already in use" });
      }
    }

    const updatedHost = await prisma.host.update({
      where: { id },
      data: {
        ...rest,
        email,
      },
    });
    res.json(updatedHost);
  } catch (error) {
    console.error("Error updating host:", error);
    res.status(500).json({ error: "An error occurred while updating host" });
  }
};

export const deleteHost = async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`Deleting host with id: ${id}`);

    const properties = await prisma.property.findMany({
      where: { hostId: id },
    });

    for (const property of properties) {
      await prisma.booking.deleteMany({ where: { propertyId: property.id } });
    }

    await prisma.property.deleteMany({ where: { hostId: id } });

    const existingHost = await prisma.host.findUnique({ where: { id } });
    if (!existingHost) {
      return res.status(404).json({ error: "Host not found" });
    }
    await prisma.host.delete({ where: { id } });
    res.status(200).end();
  } catch (error) {
    console.error("Error deleting host:", error);
    res.status(500).json({ error: "An error occurred while deleting host" });
  }
};

export const getAllHosts = async (req, res) => {
  const { name } = req.query;

  let filter = {};

  if (name) {
    filter.name = { contains: name };
  }

  try {
    const hosts = await prisma.host.findMany({
      where: filter,
    });
    res.json(hosts);
  } catch (error) {
    console.error("Error fetching hosts:", error);
    res.status(500).json({ error: "An error occurred while fetching hosts" });
  }
};
