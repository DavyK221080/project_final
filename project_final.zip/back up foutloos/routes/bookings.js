import express from "express";
import { authenticate } from "../middleware/authMiddleware.js";
import {
  getAllBookings,
  createBooking,
  getBookingById,
  updateBooking,
  deleteBooking,
} from "../services/bookingService.js";

const router = express.Router();

router.get("/", getAllBookings);
router.post("/", createBooking);
router.put("/:id", updateBooking);
router.delete("/:id", deleteBooking);
router.get("/:id", getBookingById);

export default router;
