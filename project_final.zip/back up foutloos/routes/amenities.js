import express from "express";
import {
  getAllAmenities,
  createAmenity,
  getAmenityById,
  updateAmenity,
  deleteAmenity,
} from "../services/amenityService.js";

const router = express.Router();

router.get("/", getAllAmenities);
router.post("/", createAmenity);
router.get("/:id", getAmenityById);
router.put("/:id", updateAmenity);
router.delete("/:id", deleteAmenity);

export default router;
