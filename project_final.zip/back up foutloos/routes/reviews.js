import express from "express";
import { authenticate } from "../middleware/authMiddleware.js";
import {
  createReview,
  getReviewById,
  updateReview,
  deleteReview,
  getAllReviews,
} from "../services/reviewService.js";

const router = express.Router();

router.post("/", createReview);
router.put("/:id", updateReview);
router.delete("/:id", deleteReview);
router.get("/", getAllReviews);
router.get("/:id", getReviewById);

export default router;
