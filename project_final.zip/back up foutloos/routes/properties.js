import express from "express";

import { authenticate } from "../middleware/authMiddleware.js";
import {
  getAllProperties,
  createProperty,
  getPropertyById,
  updateProperty,
  deleteProperty,
  searchProperties,
} from "../services/propertyService.js";

const router = express.Router();

router.get("/", getAllProperties);
router.post("/", createProperty);
router.put("/:id", updateProperty);
router.delete("/:id", deleteProperty);
router.get("/search", searchProperties);
router.get("/:id", getPropertyById);

export default router;
