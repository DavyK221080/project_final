import express from "express";
import { authenticate } from "../middleware/authMiddleware.js";
import {
  createHost,
  getHostById,
  updateHost,
  deleteHost,
  getAllHosts,
} from "../services/hostService.js";

const router = express.Router();

router.post("/", createHost);
router.put("/:id", updateHost);
router.delete("/:id", deleteHost);
router.get("/", getAllHosts);
router.get("/:id", getHostById);

export default router;
